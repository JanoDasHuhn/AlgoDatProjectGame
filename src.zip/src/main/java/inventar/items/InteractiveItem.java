package inventar.items;

public class InteractiveItem extends Item{
    public InteractiveItem(String name, float weight, Rarity rarity, String desc) {
        super(name, weight, rarity, desc);
    }
}
